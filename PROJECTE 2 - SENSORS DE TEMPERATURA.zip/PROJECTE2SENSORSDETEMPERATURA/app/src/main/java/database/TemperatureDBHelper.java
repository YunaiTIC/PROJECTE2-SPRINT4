package database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class TemperatureDBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "temperatures_database";
    private static final int DATABASE_VERSION = 1;

    public TemperatureDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the table to store temperature data
        String createTableQuery = "CREATE TABLE temperatures (id INTEGER PRIMARY KEY AUTOINCREMENT, floor_name TEXT, temperature REAL)";
        db.execSQL(createTableQuery);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS temperatures");
        onCreate(db);
    }







    //INSERTAR TEMPERATURES OBTINGUDES DELS DELS SENSORS A LA BASE DE DADES:
    public void insertarValors(Context context, String nomPis, double valorTemperatura) {
        // Obrim una connexió a la base de dades
        SQLiteDatabase db = this.getWritableDatabase();

        // Crea un objecte ContentValues per emmagatzemar els valors a insertar
        ContentValues valors = new ContentValues();
        valors.put("floor_name", nomPis);
        valors.put("temperature", valorTemperatura);

        // Insereix els valors a la base de dades
        long newRowId = db.insert("temperatures", null, valors);

        // Comprova si la inserció ha estat exitosa
        if (newRowId != -1) {
            Log.d("Base de dades", "Dades de temperatura inserides amb èxit.");
        } else {
            Log.d("Base de dades", "No s'ha pogut inserir les dades de temperatura.");
        }

        // Tanca la connexió a la base de dades
        db.close();
    }














}
