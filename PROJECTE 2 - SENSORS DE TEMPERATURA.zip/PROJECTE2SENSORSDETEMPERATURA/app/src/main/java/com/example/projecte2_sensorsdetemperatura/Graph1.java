package com.example.projecte2_sensorsdetemperatura;

import android.graphics.Color;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import java.util.ArrayList;

public class Graph1 extends AppCompatActivity {

    public static void setupLineChart(LineChart lineChart) {
        ArrayList<String> xAXES = new ArrayList<>();
        ArrayList<Entry> yAXESsin = new ArrayList<>();
        ArrayList<Entry> yAXEScos = new ArrayList<>();

        double x = 0;

        //Amount of data points we will have:
        int numDataPoints = 10;
        for (int i = 0; i < numDataPoints; i++) {
            float sinFunction = (float) Math.sin(x);
            float cosFunction = (float) Math.cos(x);

            x = x + 0.1;
            yAXESsin.add(new Entry(sinFunction, i));
            yAXEScos.add(new Entry(cosFunction, i));
            xAXES.add(String.valueOf(x));
        }

        ArrayList<ILineDataSet> lineDataSets = new ArrayList<>();

        LineDataSet lineDataSet1 = new LineDataSet(yAXEScos, "cos");
        lineDataSet1.setDrawCircles(false);
        lineDataSet1.setColor(Color.BLUE);

        LineDataSet lineDataSet2 = new LineDataSet(yAXESsin, "sin");
        lineDataSet2.setDrawCircles(false);
        lineDataSet2.setColor(Color.RED);

        lineDataSets.add(lineDataSet1);
        lineDataSets.add(lineDataSet2);

        ILineDataSet[] dataSetsArray = lineDataSets.toArray(new ILineDataSet[lineDataSets.size()]);

        lineChart.setData(new LineData(dataSetsArray));
        lineChart.setVisibleXRangeMaximum(65f);
    }
}
