package com.example.projecte2_sensorsdetemperatura;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.projecte2_sensorsdetemperatura.Graph1;
import com.example.projecte2_sensorsdetemperatura.R;

public class ConsumEnergiaActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.benvinguda);

        // Button click handling for consum_energia
        Button consumEnergiaButton = findViewById(R.id.consum_energia);
        consumEnergiaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ConsumEnergiaActivity.this, Graph1.class);
                startActivity(intent);
            }
        });
    }
}
