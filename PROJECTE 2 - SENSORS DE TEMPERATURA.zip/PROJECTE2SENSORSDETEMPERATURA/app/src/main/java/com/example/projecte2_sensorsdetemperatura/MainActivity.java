package com.example.projecte2_sensorsdetemperatura;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.benvinguda);


        Button add_temperatura = findViewById(R.id.bttn_add);
        add_temperatura.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddActivity.class);
                startActivity(intent);
            }
        });
        Button control_temperatura = findViewById(R.id.control_temperatura);
        control_temperatura.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ControlTemperaturaActivity.class);
                startActivity(intent);
            }
        });
        Button NotisButton = findViewById(R.id.button4);
        NotisButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Notificaciones.class);
                startActivity(intent);
            }
        });

        Button consumEnergiaButton = findViewById(R.id.consum_energia);
        consumEnergiaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Graph1.class);
                startActivity(intent);
            }
        });
        /*
        Button historialButton = findViewById(R.id.btn_historial);
        historialButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the click, you can start a new activity here
                // For example:
                Intent intent = new Intent(BenvingudaActivity.this, HistorialActivity.class);
                startActivity(intent);
            }
        });



        Button controlTemperaturaButton = findViewById(R.id.control_temperatura);
        controlTemperaturaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the click, you can start a new activity here
                // For example:
                Intent intent = new Intent(MainActivity.this, ControlTemperaturaActivity.class);
                startActivity(intent);
            }
        });

        Button consumEnergiaButton = findViewById(R.id.consum_energia);
        consumEnergiaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the click, you can start a new activity here
                // For example:
                Intent intent = new Intent(MainActivity.this, ConsumEnergiaActivity.class);
                startActivity(intent);
            }
        });

        /*
        Button notificacionsButton = findViewById(R.id.button4);
        notificacionsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the click, you can start a new activity here
                // For example:
                Intent intent = new Intent(BenvingudaActivity.this, NotificacionsActivity.class);
                startActivity(intent);
            }
        });

         */
    }
}
